declare module "prop-types" {
    const PropTypes: any;
    export default PropTypes;
  }
  